document.addEventListener('DOMContentLoaded', () => {
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const dotsContainer = document.querySelector('.dot-indicators');
    const dots = document.querySelectorAll('.dot');
    let currentSlide = 0;
    let slideInterval; // Untuk menyimpan ID interval agar bisa dihentikan

    // Fungsi untuk menampilkan slide tertentu
    // Tambahkan kelas 'active-link' secara otomatis pada link navbar sesuai halaman saat ini

    document.querySelectorAll('.navbar a').forEach(link => {
        if (link.href === window.location.href) {
            link.classList.add('active-link');
        }
    });



    function showSlide(index) {
        // Sembunyikan semua slide dan hapus kelas 'active'
        slides.forEach((slide, i) => {
            slide.classList.remove('active');
            // Pastikan dots ada sebelum mengakses
            if (dots[i]) {
                dots[i].classList.remove('active');
            }
        });

        // Tampilkan slide yang aktif dan tambahkan kelas 'active'
        if (slides[index]) {
            slides[index].classList.add('active');
        }
        if (dots[index]) {
            dots[index].classList.add('active');
        }
        currentSlide = index;
    }

    // Fungsi untuk maju ke slide berikutnya
    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }

    // Fungsi untuk mundur ke slide sebelumnya
    function prevSlide() {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(currentSlide);
    }

    // Fungsi untuk memulai autoplay
    function startAutoplay() {
        stopAutoplay(); // Pastikan tidak ada interval ganda
        slideInterval = setInterval(nextSlide, 5000); // Ganti slide setiap 5 detik (5000ms)
    }

    // Fungsi untuk menghentikan autoplay
    function stopAutoplay() {
        clearInterval(slideInterval);
    }

    // Event listeners untuk tombol navigasi (jika ada)
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            stopAutoplay();
            prevSlide();
            startAutoplay();
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            stopAutoplay();
            nextSlide();
            startAutoplay();
        });
    }

    // Event listeners untuk indikator titik (jika ada)
    if (dotsContainer) {
        dotsContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('dot')) {
                const slideIndex = parseInt(e.target.dataset.slide);
                stopAutoplay();
                showSlide(slideIndex);
                startAutoplay();
            }
        });
    }

    // Inisialisasi: Tampilkan slide pertama dan mulai autoplay
    if (slides.length > 0) {
        showSlide(currentSlide);
        startAutoplay();
    }

    // Optional: Hentikan autoplay saat mouse masuk dan mulai lagi saat mouse keluar dari banner
    const banner = document.querySelector('.banner');
    if (banner) {
        banner.addEventListener('mouseenter', stopAutoplay);
        banner.addEventListener('mouseleave', startAutoplay);
    }
});